<html>
<head>
<title>Test/Index</title>
<style>
    body {font-size:16px; color:#999;}
    h1 {font-size:100px; text-align:right; color:#eee;
        margin:-40px 0px -50px 0px;}
</style>
</head>
<body>
    <h1>Index</h1>
    <p>This is a sample page with php-template.</p>
    <p><?php echo $msg; ?></p>
    <p><?php echo date("Y年n月j日"); ?></p>
</body>
</html>
    