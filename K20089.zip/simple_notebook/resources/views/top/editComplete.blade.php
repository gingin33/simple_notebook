@extends('top.template')

@section('title', 'かんたん備忘録')

@section('pageTitle', '変更完了')

@section('contents')
    <div class="contentForms">
        <h2>登録内容の変更が完了しました。</h2>
        <a href="/" class="back">トップへ</a>
    </div>
@endsection