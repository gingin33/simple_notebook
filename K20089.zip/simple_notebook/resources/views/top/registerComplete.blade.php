@extends('top.template')

@section('title', 'かんたん備忘録')

@section('pageTitle', '新規登録完了')

@section('contents')
    <div class="contentForms">
        <h2>新規登録完了しました。</h2>
        <a href="/login" class="back">ログインへ</a>
    </div>
@endsection