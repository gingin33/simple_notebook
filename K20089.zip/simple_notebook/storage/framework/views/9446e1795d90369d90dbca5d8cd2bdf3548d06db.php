<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body>
        <div class="header"> 
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        <div class="pageTitle">
            <h2><?php echo $__env->yieldContent('pageTitle'); ?></h2>
        <div class="sideBar">
            <?php if(!$isLogged): ?>
                <a href="/login">ログイン</a>
            <?php else: ?>
                <a href="/mypage">マイ備忘録</a>
                <a href="/faves">いいねした備忘録</a>
            <?php endif; ?>
        </div>
    </body>
</html><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/top.blade.php ENDPATH**/ ?>