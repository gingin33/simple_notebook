<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '登録情報チェック'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contentForms">
        <p>以下の内容でよろしいでしょうか？</p>
        <form action="/register/complete" method="post">
            <table class="forms">
                <tr><th>ユーザネーム : </th><td><?php echo e($user); ?></td></tr>
                <tr><th>メールアドレス : </th><td><?php echo e($mail); ?></td></tr>
                <tr><th>パスワード : </th><td><?php echo str_repeat("*", mb_strlen($pass, "UTF8")); ?></td></tr>
                
                <tr><th><input type="submit" value="OK" class="submit"></th><td><input type="button" value="戻る" onclick="history.back()" class="submit"></td></tr>
            </table>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/registerConfirm.blade.php ENDPATH**/ ?>