<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '登録情報チェック'); ?>

<?php $__env->startSection('contents'); ?>
    <p>以下の内容でよろしいでしょうか？</p>
    <table class="forms">
        <tr><th>ユーザID : </th><td><?php echo e($user); ?></td></tr>
        <tr><th>パスワード : </th><td><?php echo e($pass); ?></td></tr>
        <tr><th></th><td><input type="submit" value="OK"></td><td><input type="button" value="戻る" onclick="history.back()"></td></tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/registerCheck.blade.php ENDPATH**/ ?>