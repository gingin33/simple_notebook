<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', 'マイ備忘録'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contain">
        <div class="sideBar">
            <div class="sideBarContent">
                <?php if(session('login_id')): ?>
                    <a href="/">最新の備忘録</a>
                    <a href="/edit">登録情報変更</a>
                    <a href="/logout">ログアウト</a>
                <?php else: ?>
                    <a href="/login">ログイン</a>
                <?php endif; ?>
                <form action="/upload" method="post"> 
                    <?php echo csrf_field(); ?>
                    <table class="uploadForm">
                        <?php if(session('login_id')): ?>
                            <tr><th class="uploadColumn">Name</th><td><?php echo e(session('login_user')); ?></td></tr>
                        <?php else: ?>  
                            <tr><th>Name</th><td>名無し</td></tr>
                        <?php endif; ?>

                        <?php if($errors->has('title')): ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                        <tr><th class="uploadColumn">Title</th><td><input type="text" name="title" value="<?php echo e(old('title')); ?>"></input></td></tr>

                        <?php if($errors->has('texts')): ?>
                        <?php $__errorArgs = ['texts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                        <tr><th class="uploadColumn"></th><td><textarea cols=30 rows=5 name="texts" value="<?php echo e(old('texts')); ?>"></textarea></td></tr>
                        <?php if(session('login_id')): ?>
                            <tr><th class="uploadColumn">Private</th><td><input type="checkbox" name="isPrivate[]"></td></tr>
                        <?php endif; ?>
                        <tr><th></th><td><input type="submit" class="submit"></input></td></tr>
                    </table>
            </form> 
            </div>
        </div>
        <div class="notes">
            <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="note">
                    <div class="noteTitle">
                        <h3> <?php echo e($note->subject); ?> </h3>
                    </div>
                    <div class="noteText"><?php echo e($note->text); ?></div>
                    <div class="noteInfo">
                        <div class="createdAt"><?php echo e($note->created_at); ?></div>
                        <div class="userName">
                            by <?php echo e($note->user->user_name); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="pager">
                <?php echo e($notes->links()); ?>

            </div>
            <form action="/upload" method="post"> 
                    <?php echo csrf_field(); ?>
                    <table class="uploadForm">
                        <?php if(session('login_id')): ?>
                            <tr><th class="uploadColumn">名前</th><td><?php echo e(session('login_user')); ?></td></tr>
                        <?php else: ?>  
                            <tr><th class="uploadColumn">名前</th><td>名無し</td></tr>
                        <?php endif; ?>

                        <?php if($errors->has('title')): ?>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                        <tr><th class="uploadColumn">タイトル</th><td><input type="text" name="title"></input></td></tr>

                        <?php if($errors->has('texts')): ?>
                        <?php $__errorArgs = ['texts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php endif; ?>
                        <tr><th class="uploadColumn"></th><td><textarea cols=50 rows=10 name="texts"></textarea></td></tr>
                        <tr><th class="uploadColumn">プライベート投稿にする</th><td><input type="checkbox" name="isPrivate[]"></td></tr>
                        <tr><th></th><td><input type="submit" class="submit"></input></td></tr>
                    </table>
            </form> 
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/mypage.blade.php ENDPATH**/ ?>