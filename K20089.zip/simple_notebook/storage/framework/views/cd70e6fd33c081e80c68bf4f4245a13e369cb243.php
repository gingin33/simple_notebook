<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '投稿内容チェック'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contentForms"> 
        <p>以下の内容でよろしいでしょうか？</p>
        <form action="/upload/complete" method="post">
            <table class="forms">
                <?php echo csrf_field(); ?>
                <tr><th>タイトル : </th><td><?php echo e($title); ?></td></tr>
                <tr><th>本文 : </th><td><?php echo e($texts); ?></td></tr>
                <?php if(session('login_id')): ?>
                    <tr><th>プライベートか : </th><td>
                        <?php if($isPrivate): ?>
                            YES
                        <?php else: ?>
                            NO
                        <?php endif; ?>
                <?php endif; ?>
                <tr><th><input type="submit" value="OK" class="submit"></th><td><input type="button" value="戻る" onclick="history.back()" class="submit"></td></tr>
            </table>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/uploadConfirm.blade.php ENDPATH**/ ?>