<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '新規登録完了'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contentForms">
        <h2>新規登録完了しました。</h2>
        <a href="/login">ログインへ</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/registerComplete.blade.php ENDPATH**/ ?>