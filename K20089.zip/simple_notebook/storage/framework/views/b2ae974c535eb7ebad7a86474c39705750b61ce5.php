<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '変更完了'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contentForms">
        <h2>登録内容の変更が完了しました。</h2>
        <a href="/">トップへ</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/editComplete.blade.php ENDPATH**/ ?>