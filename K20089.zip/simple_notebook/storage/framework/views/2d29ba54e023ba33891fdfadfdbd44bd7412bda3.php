<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <div class="header"> 
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        <div class="pageTitle">
            <h2><?php echo $__env->yieldContent('pageTitle'); ?></h2>
        </div>
        <table class="forms">
            <?php echo csrf_field(); ?>
            <tr><th>ユーザID : </th><td><input type="text" name="name"></td></tr>
            <tr><th>パスワード : </th><td><input type="text" name="name"></td></tr>
            <tr><th><input type="submit" value="ログイン"></td></tr>
        </table>
    </body>
</html><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/loginTemplate.blade.php ENDPATH**/ ?>