<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '登録情報変更'); ?>

<?php $__env->startSection('contents'); ?>
<div class="contentForms">
<?php if(count($errors) > 0): ?>
    <p class="err">入力に問題があります。</p>
    <?php endif; ?>
    <form action="/edit" method="post">
        <table class="forms">
            <?php echo csrf_field(); ?>
            <?php if($errors->has('user')): ?>
            <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
            <tr><th>ユーザネーム : </th><td><input type="text" name="user" value="<?php echo e($user->user_name); ?>"></td></tr>

            <?php if($errors->has('mail')): ?>
            <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
            <tr><th>メールアドレス : </th><td><input type="text" name="mail" value="<?php echo e($user->email); ?>"></td></tr>

            <?php if($errors->has('pass')): ?>
            <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
            <tr><th>パスワード : </th><td><input type="password" name="pass" value=""></td></tr>

            <?php if($errors->has('passCheck')): ?>
            <?php $__errorArgs = ['passCheck'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <tr class="err"><th></th><td><?php echo e($message); ?></td></tr>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>
            <tr><th>パスワード確認 : </th><td><input type="password" name="passCheck" value=""></td></tr>
            <tr><th></th><td><input type="submit" value="登録" class="submit"></td></tr>
        </table>
    </form>
    <a href="/">トップへ</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/editUser.blade.php ENDPATH**/ ?>