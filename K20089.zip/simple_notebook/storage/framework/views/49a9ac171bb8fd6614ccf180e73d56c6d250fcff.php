<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', 'ログイン'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="contentForms">
        <div class="regist">
            <a href="/register">新規登録</a>
        </div>
        <?php if(isset($isLoginError)): ?>
        <div class="err">メールアドレスかパスワードが違います.</div>
        <?php endif; ?>  
        <form action="/" method="post">
            <table class="forms">
                <?php echo csrf_field(); ?>
                <tr><th>メールアドレス : </th><td><input type="text" name="mail"></td></tr>
                <tr><th>パスワード : </th><td><input type="password" name="pass"></td></tr>
                <tr><th></th><td><input type="submit" value="ログイン" class="submit"></td></tr>
            </table>
        </form>
        <div class="back"><a href="/" class="back">トップへ</a></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/login.blade.php ENDPATH**/ ?>