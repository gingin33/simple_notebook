<?php $__env->startSection('title', 'かんたん備忘録'); ?>

<?php $__env->startSection('pageTitle', '投稿完了'); ?>

<?php $__env->startSection('contents'); ?>
    <h3>投稿完了しました。</h3>
    <a href="/">トップへ</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('top.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/k20089kk/Documents/GitHub/simple_notebook/simple_notebook/resources/views/top/uploadComplete.blade.php ENDPATH**/ ?>